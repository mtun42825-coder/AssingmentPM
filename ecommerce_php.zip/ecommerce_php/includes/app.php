<?php
/** Shared helpers used by the storefront pages. Keep output escaped with e(). */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(0, '/', '', false, true);
    session_start();
}

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url)
{
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf()
{
    $submitted = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';

    if (!is_string($submitted) || !hash_equals(csrf_token(), $submitted)) {
        http_response_code(419);
        exit('Your form expired. Go back, refresh the page, and try again.');
    }
}

function set_flash(string $type, string $message)
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash()
{
    $flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : null;

    unset($_SESSION['flash']);

    return is_array($flash) ? $flash : null;
}

function require_admin()
{
    if (empty($_SESSION['user'])) {
        set_flash(
            'warning',
            'Please sign in with an administrator account to manage products.'
        );

        redirect('login.php');
    }

    $role = isset($_SESSION['user']['role'])
        ? $_SESSION['user']['role']
        : 'customer';

    if ($role !== 'admin') {
        http_response_code(403);
        exit('You do not have permission to manage products.');
    }
}

/** Store an optional uploaded product image and return its relative path. */
function store_product_image(array $file)
{
    $error = isset($file['error'])
        ? $file['error']
        : UPLOAD_ERR_NO_FILE;

    if ($error === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException(
            'The image could not be uploaded. Please try again.'
        );
    }

    $size = isset($file['size']) ? $file['size'] : 0;
    $tmpName = isset($file['tmp_name']) ? $file['tmp_name'] : '';

    if ($size > 5 * 1024 * 1024 || !is_uploaded_file($tmpName)) {
        throw new RuntimeException(
            'Choose an image smaller than 5 MB.'
        );
    }

    $imageInfo = @getimagesize($tmpName);

    $extensions = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];

    $mime = isset($imageInfo['mime'])
        ? $imageInfo['mime']
        : '';

    if (!isset($extensions[$mime])) {
        throw new RuntimeException(
            'Use a JPG, PNG, GIF, or WebP image.'
        );
    }

    $directory = dirname(__DIR__) . '/uploads/products';

    if (
        !is_dir($directory) &&
        !mkdir($directory, 0755, true) &&
        !is_dir($directory)
    ) {
        throw new RuntimeException(
            'The product image folder could not be created.'
        );
    }

    $filename = bin2hex(random_bytes(16))
        . '.'
        . $extensions[$mime];

    if (
        !move_uploaded_file(
            $tmpName,
            $directory . '/' . $filename
        )
    ) {
        throw new RuntimeException(
            'The product image could not be saved. Check folder permissions.'
        );
    }

    return 'uploads/products/' . $filename;
}

function product_image_path($image): string
{
    $image = (string) $image;

    if (
        $image !== '' &&
        preg_match(
            '~^(images|uploads/products)/[A-Za-z0-9_-]+\.(jpe?g|png|gif|webp)$~iD',
            $image
        )
    ) {
        return $image;
    }

    return 'images/classic_booki_burger.jpg';
}
?>