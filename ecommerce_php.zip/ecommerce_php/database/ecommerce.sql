-- Panel-X Kitchen schema and sample data for MySQL/MariaDB (XAMPP).
-- WARNING: Importing this file drops and recreates only the project tables listed below.
-- Back up existing project data before importing if you need to preserve it.
CREATE DATABASE IF NOT EXISTS ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerce;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_username (username),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(80) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    stock INT UNSIGNED NOT NULL DEFAULT 0,
    image VARCHAR(255) NOT NULL DEFAULT 'images/classic_booki_burger.jpg',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_products_category (category),
    KEY idx_products_stock (stock),
    CONSTRAINT chk_products_price CHECK (price > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(190) NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    status ENUM('new', 'preparing', 'completed', 'cancelled') NOT NULL DEFAULT 'new',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_orders_user_created (user_id, created_at),
    CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id BIGINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NULL,
    product_title VARCHAR(150) NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_order_items_order (order_id),
    KEY idx_order_items_product (product_id),
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT chk_order_item_quantity CHECK (quantity > 0),
    CONSTRAINT chk_order_item_price CHECK (unit_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE contact_messages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contact_messages_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Demo administrator: username admin / password PanelXAdmin2026!
-- Change this password after first login on any publicly accessible installation.
INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@panelx.local', '$2y$10$85PNFFgKId1paWafYqS47u8icoyLiemx20EVgmVc6AedcpdvET4Ye', 'admin');

INSERT INTO products (title, description, category, price, stock, image) VALUES
('Classic Booki Burger', 'A juicy classic burger layered with fresh greens and savoury sauce.', 'Burgers', 4500.00, 25, 'images/classic_booki_burger.jpg'),
('Spicy Chicken Sandwich', 'Crispy chicken with a gentle kick, served with a fresh salad crunch.', 'Burgers', 5500.00, 18, 'images/spicy_chicken_sandwich.jpg'),
('Veggie Delight Burger', 'A colourful plant-forward burger packed with crisp vegetables.', 'Burgers', 4800.00, 16, 'images/veggie_delight_burger.jpg'),
('Creamy Carbonara', 'Creamy pasta finished with herbs and a generous savoury topping.', 'Pasta', 6500.00, 14, 'images/carbonara.jpg'),
('Booki Fries', 'Golden, crisp fries with a pinch of seasoning.', 'Sides', 2200.00, 30, 'images/booki_fries.jpg'),
('Onion Rings', 'Crunchy battered onion rings, perfect for sharing.', 'Sides', 2800.00, 20, 'images/onion_rings.jpg'),
('Fresh Orange Juice', 'A chilled glass of bright, refreshing orange juice.', 'Drinks', 1800.00, 22, 'images/orange_juice.jpg'),
('Coca-Cola', 'A cold, fizzy soft drink served chilled.', 'Drinks', 1500.00, 36, 'images/coca_cola.jpg');
