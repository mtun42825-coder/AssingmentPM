<?php
require_once __DIR__ . '/connection.php';
$_SESSION['cart'] = is_array($_SESSION['cart'] ?? null) ? $_SESSION['cart'] : [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $productId = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($action === 'clear') {
        $_SESSION['cart'] = [];
        set_flash('success', 'Your cart has been cleared.');
    } elseif (!$productId) {
        set_flash('danger', 'That menu item could not be found.');
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][$productId]);
        set_flash('success', 'The item was removed from your cart.');
    } elseif ($action === 'add' || $action === 'update') {
        $stmt = $conn->prepare('SELECT stock FROM products WHERE id = ?');
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $requested = max(1, min(99, (int) ($_POST['quantity'] ?? 1)));
        $target = $action === 'add' ? (int) ($_SESSION['cart'][$productId] ?? 0) + $requested : $requested;
        if (!$product || (int) $product['stock'] < 1) {
            unset($_SESSION['cart'][$productId]);
            set_flash('danger', 'This item is no longer available.');
        } elseif ($target > (int) $product['stock']) {
            $_SESSION['cart'][$productId] = (int) $product['stock'];
            set_flash('warning', 'Cart quantity adjusted to the available stock.');
        } else {
            $_SESSION['cart'][$productId] = $target;
            set_flash('success', $action === 'add' ? 'Added to your cart.' : 'Cart quantity updated.');
        }
    } else {
        set_flash('danger', 'That cart action is not available.');
    }
    redirect('cart.php');
}

$items = [];
$total = 0.0;
foreach ($_SESSION['cart'] as $id => $quantity) {
    $id = (int) $id;
    $stmt = $conn->prepare('SELECT id, title, price, image, stock FROM products WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    if (!$product || (int) $product['stock'] < 1) {
        unset($_SESSION['cart'][$id]);
        continue;
    }
    $quantity = max(1, min((int) $quantity, (int) $product['stock']));
    $_SESSION['cart'][$id] = $quantity;
    $product['quantity'] = $quantity;
    $product['line_total'] = (float) $product['price'] * $quantity;
    $total += $product['line_total'];
    $items[] = $product;
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your Cart | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?>
    <main class="container py-5 mt-5">
        <div class="pt-4 d-flex justify-content-between align-items-end">
            <div>
                <h1 class="fw-bold">Your cart</h1>
                <p class="text-secondary">Review your items before checkout.</p>
            </div>
            <a href="shop.php" class="btn btn-outline-primary mb-3">Continue shopping</a>
        </div>
        <?php if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?>
            </div>
        <?php endif; ?>
        <?php if (!$items): ?>
            <div class="bg-white rounded-4 shadow-sm p-5 text-center">
                <i class="bi bi-basket display-4 text-primary"></i>
                <h2 class="h4 mt-3">Your cart is empty</h2>
                <p class="text-secondary">Browse the menu and add something you like.</p>
                <a href="shop.php" class="btn btn-primary-custom">Browse the menu</a>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-4 shadow-sm p-3 p-md-4">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th class="text-end">Subtotal</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody><?php foreach ($items as $item): ?><tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-3">
                                            <img src="<?= e(product_image_path($item['image'])) ?>" alt="" width="64" height="64" class="rounded" style="object-fit:cover">
                                            <strong><?= e($item['title']) ?></strong>
                                        </div>
                                    </td>
                                    <td><?= number_format((float) $item['price'], 0) ?> MMK</td>
                                    <td>
                                        <form method="post" action="cart.php" class="d-flex gap-2"><?= csrf_field() ?>
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="product_id" value="<?= (int) $item['id'] ?>">
                                            <input type="number" name="quantity" min="1" max="<?= (int) $item['stock'] ?>" value="<?= (int) $item['quantity'] ?>" class="form-control" style="width:90px" aria-label="Quantity for <?= e($item['title']) ?>">
                                            <button class="btn btn-outline-primary" type="submit">Update</button>
                                        </form>
                                    </td>
                                    <td class="text-end fw-bold"><?= number_format($item['line_total'], 0) ?> MMK</td>
                                    <td>
                                        <form method="post" action="cart.php"><?= csrf_field() ?>
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="product_id" value="<?= (int) $item['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit" aria-label="Remove <?= e($item['title']) ?>">Remove</button>
                                        </form>
                                    </td>
                                </tr><?php endforeach; ?></tbody>
                    </table>
                </div>
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mt-3">
                    <form method="post" action="cart.php"><?= csrf_field() ?>
                        <input type="hidden" name="action" value="clear">
                        <button class="btn btn-link text-danger px-0" type="submit">Clear cart</button>
                    </form>
                    <div class="text-md-end">
                        <p class="h4 mb-3">Total: <?= number_format($total, 0) ?> MMK</p>
                        <a href="checkout.php" class="btn btn-primary-custom px-4 py-2">Proceed to checkout</a>
                    </div>
                </div>
            </div><?php endif; ?>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>