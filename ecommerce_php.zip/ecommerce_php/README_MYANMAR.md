# Panel-X Kitchen — XAMPP စတင်အသုံးပြုရန်

## တပ်ဆင်ခြင်း

1. XAMPP Control Panel မှ **Apache** နှင့် **MySQL** ကို Start လုပ်ပါ။
2. `ecommerce_php` folder ကို `C:\xampp\htdocs\ecommerce_php` ထဲသို့ copy လုပ်ပါ။
3. Browser တွင် `http://localhost/phpmyadmin` ကို ဖွင့်ပါ။ **Import** ကိုရွေးပြီး project ထဲက `database/ecommerce.sql` ကို ရွေးကာ **Go** ကိုနှိပ်ပါ။ SQL ဖိုင်က `ecommerce` database ကို ဖန်တီးပြီး tables နှင့် sample menu ပစ္စည်းများကို ထည့်ပေးပါမည်။
4. `http://localhost/ecommerce_php/` ကို ဖွင့်ပါ။

> သတိပြုရန် — SQL ဖိုင်သည် အမည်တူရှိပြီးသား `ecommerce` database အတွင်းရှိ ဒီ project ၏ `users`, `products`, `orders`, `order_items`, `contact_messages` tables များကို ပြန်ဖန်တီးပါသည်။ အဲဒီ tables ထဲမှာ ကိုယ်ပိုင်ဒေတာရှိပြီးသားဆိုရင် import မလုပ်ခင် backup ယူပါ။

## စမ်းသပ်ရန် Admin အကောင့်

- Username: `admin`
- Password: `PanelXAdmin2026!`

Admin အကောင့်ဖြင့် Login ဝင်ပြီး **Inventory** မှ ပစ္စည်းအသစ်ထည့်ခြင်း၊ ပြင်ဆင်ခြင်း၊ ဖျက်ခြင်းနှင့် stock စမ်းသပ်နိုင်ပါသည်။ အခြား Register လုပ်သောအကောင့်များသည် customer အကောင့်ဖြစ်ပြီး inventory ကို မပြင်နိုင်ပါ။

## စမ်းသပ်နိုင်သော လုပ်ဆောင်ချက်များ

- Register / Login / Logout
- Menu မှ ပစ္စည်းရွေး၍ Cart ထဲထည့်ခြင်း၊ quantity ပြင်ခြင်း
- Checkout မှ order တင်ခြင်း — order နှင့် order items ကို database ထဲသိမ်းပြီး stock လျှော့ပေးသည်။ **ငွေပေးချေမှု မပါဝင်ပါ။**
- Home page ရှိ Contact form မှ message ပို့ခြင်း
- Admin Inventory မှ product CRUD နှင့် stock စီမံခြင်း

## ဖွဲ့စည်းပုံနှင့် မှတ်ချက်များ

- `connection.php` တွင် XAMPP မူလ MySQL ချိတ်ဆက်မှု (`localhost`, `root`, password မရှိ) ကို သတ်မှတ်ထားသည်။ လိုအပ်ပါက `DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME` environment variables ဖြင့် ပြောင်းနိုင်သည်။
- `includes/app.php` တွင် session, output escaping, CSRF နှင့် image upload helper များရှိသည်။
- Upload လုပ်သောပုံများကို `uploads/products/` ထဲသို့ သိမ်းသည်။
- SQL import ကို သန့်ရှင်းသော local setup တွင် တစ်ကြိမ်လုပ်ရန် ရည်ရွယ်ထားသည်။
