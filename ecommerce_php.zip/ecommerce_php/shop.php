<?php
require_once __DIR__ . '/connection.php';
$flash = get_flash();
$sort = (string) ($_GET['sort'] ?? 'newest');
$sortOptions = [
    'newest' => 'id DESC',
    'oldest' => 'id ASC',
    'name_asc' => 'title ASC',
    'name_desc' => 'title DESC',
    'price_asc' => 'price ASC, title ASC',
    'price_desc' => 'price DESC, title ASC',
];
if (!isset($sortOptions[$sort])) {
    $sort = 'newest';
}
$category = trim((string) ($_GET['category'] ?? ''));
$categoryStmt = $conn->prepare('SELECT category, COUNT(*) AS item_count FROM products GROUP BY category ORDER BY category');
$categoryStmt->execute();
$categories = $categoryStmt->get_result();
if ($category !== '') {
    $stmt = $conn->prepare('SELECT id, title, description, category, price, stock, image FROM products WHERE category = ? AND stock > 0 ORDER BY ' . $sortOptions[$sort]);
    $stmt->bind_param('s', $category);
} else {
    $stmt = $conn->prepare('SELECT id, title, description, category, price, stock, image FROM products WHERE stock > 0 ORDER BY ' . $sortOptions[$sort]);
}
$stmt->execute();
$products = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Menu | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .product-card img {
            width: 100%;
            height: 245px;
            object-fit: cover
        }

        .product-card a {
            text-decoration: none
        }
    </style>
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?>
    <header class="py-4 bg-white border-bottom mt-5">
        <div class="container pt-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Menu</li>
                </ol>
            </nav>
            <h1 class="fw-bold mb-1">Our menu</h1>
            <p class="text-secondary mb-0">Choose your Danger-X favourites.</p>
        </div>
    </header>
    <main class="container py-5">
        <div class="row g-4">
            <aside class="col-lg-3">
                <div class="bg-white rounded-4 p-4 shadow-sm">
                    <h5 class="fw-bold mb-3">Categories</h5>
                    <a class="d-flex justify-content-between text-decoration-none text-secondary py-2 <?= $category === '' ? 'fw-bold text-primary' : '' ?>" href="shop.php">
                        <span>All items</span>
                    </a>
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                        <a class="d-flex justify-content-between text-decoration-none text-secondary py-2 <?= $category === $cat['category'] ? 'fw-bold text-primary' : '' ?>" href="shop.php?category=<?= rawurlencode($cat['category']) ?>">
                            <span><?= e($cat['category']) ?></span>
                            <span><?= (int) $cat['item_count'] ?>
                            </span></a><?php endwhile; ?>
                    <?php if (($_SESSION['user']['role'] ?? '') === 'admin'): ?>
                        <hr><a href="product.php" class="btn btn-outline-primary w-100">Manage inventory</a><?php endif; ?>
                </div>
            </aside>
            <section class="col-lg-9">
                <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-4 bg-white p-3 rounded-3 shadow-sm">
                    <p class="mb-0 text-secondary">Showing <?= $products->num_rows ?> available item<?= $products->num_rows === 1 ? '' : 's' ?></p>
                    <form method="get" action="shop.php" class="d-flex gap-2"><?php if ($category !== ''): ?>
                            <input type="hidden" name="category" value="<?= e($category) ?>"><?php endif; ?>
                        <label class="visually-hidden" for="sort">Sort menu</label>
                        <select id="sort" class="form-select w-auto bg-light" name="sort" onchange="this.form.submit()">
                            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
                            <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>Oldest</option>
                            <option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Name: A to Z</option>
                            <option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Name: Z to A</option>
                            <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: low to high</option>
                            <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: high to low</option>
                        </select>
                    </form>
                </div>
                <?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
                <?php endif; ?>
                <div class="row g-4">
                    <?php if ($products->num_rows === 0): ?><div class="col-12">
                            <div class="bg-white rounded-4 p-5 text-center">
                                <h2 class="h4">No menu items found</h2>
                                <p class="text-secondary mb-0">Try another category or check back soon.</p>
                            </div>
                        </div><?php endif; ?>
                    <?php while ($item = $products->fetch_assoc()): ?>
                        <div class="col-md-6 col-xl-4">
                            <article class="card h-100 border-0 shadow-sm product-card">
                                <img src="<?= e(product_image_path($item['image'])) ?>" class="card-img-top p-2 rounded-4" alt="<?= e($item['title']) ?>">
                                <div class="card-body d-flex flex-column">
                                    <span class="small text-muted mb-1"><?= e($item['category']) ?>
                                    </span>
                                    <h2 class="h5 card-title fw-bold"><?= e($item['title']) ?></h2>
                                    <p class="text-secondary small flex-grow-1"><?= e($item['description']) ?></p>
                                    <div class="d-flex justify-content-between align-items-center mt-2"><span class="h5 fw-bold mb-0 text-primary">
                                            <?= number_format((float) $item['price'], 0) ?> MMK</span>
                                        <form method="post" action="cart.php"><?= csrf_field() ?><input type="hidden" name="action" value="add">
                                            <input type="hidden" name="product_id" value="<?= (int) $item['id'] ?>">
                                            <button type="submit" class="btn btn-primary-custom" <?= (int) $item['stock'] < 1 ? 'disabled' : '' ?>>Add to cart</button>
                                        </form>
                                    </div><small class="text-muted mt-2">Stock: <?= (int) $item['stock'] ?></small>
                                </div>
                            </article>
                        </div><?php endwhile; ?>
                </div>
            </section>
        </div>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>