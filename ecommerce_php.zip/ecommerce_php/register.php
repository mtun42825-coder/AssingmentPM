<?php
require_once __DIR__ . '/connection.php';
if (!empty($_SESSION['user'])) {
    redirect('shop.php');
}
$error = '';
$username = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string) ($_POST['username'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    if ($username === '' || mb_strlen($username) > 50 || !preg_match('/^[\p{L}\p{N}_. -]+$/u', $username)) {
        $error = 'Choose a username (up to 50 letters, numbers, spaces, dots, underscores, or hyphens).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        $error = 'Enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Choose a password with at least 8 characters.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $conn->prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $username, $email, $hash);
            $stmt->execute();
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => (int) $conn->insert_id, 'username' => $username, 'email' => $email, 'role' => 'customer'];
            set_flash('success', 'Your account is ready. Welcome to Danger-X Kitchen!');
            redirect('shop.php');
        } catch (mysqli_sql_exception $exception) {
            $error = ((int) $exception->getCode() === 1062) ? 'That username or email is already registered.' : 'Registration could not be completed. Please try again.';
        }
    }
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?><main class="container py-5 mt-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5">
                <div class="bg-white rounded-4 shadow-sm p-4 p-md-5">
                    <a href="index.php" class="text-decoration-none text-primary">← Back to home</a>
                    <h1 class="h2 fw-bold mt-4 mb-4">Create your account</h1>
                    <?php if ($flash): ?>
                        <div class="alert alert-<?= e($flash['type']) ?>">
                            <?= e($flash['message']) ?>
                        </div><?php endif; ?>
                    <?php if ($error !== ''): ?>
                        <div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
                    <form method="post" action="register.php" autocomplete="on"><?= csrf_field() ?>
                        <div class="mb-3"><label class="form-label fw-bold" for="username">Username</label>
                            <input class="form-control" id="username" name="username" maxlength="50" value="<?= e($username) ?>" required autocomplete="username">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold" for="email">Email</label>
                            <input class="form-control" id="email" name="email" type="email" maxlength="190" value="<?= e($email) ?>" required autocomplete="email">
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold" for="password">Password</label>
                            <input class="form-control" id="password" name="password" type="password" minlength="8" required autocomplete="new-password">
                            <div class="form-text">Use at least 8 characters.</div>
                        </div>
                        <button class="btn btn-primary-custom w-100 py-3" type="submit">Register</button>
                    </form>
                    <p class="small text-secondary text-center mt-4 mb-0">Already registered? <a href="login.php">Log in</a></p>
                </div>
            </div>
        </div>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>