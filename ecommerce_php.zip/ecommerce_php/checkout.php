<?php
require_once __DIR__ . '/connection.php';
$_SESSION['cart'] = is_array($_SESSION['cart'] ?? null) ? $_SESSION['cart'] : [];
$error = '';
$name = (string) ($_SESSION['user']['username'] ?? '');
$email = (string) ($_SESSION['user']['email'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string) ($_POST['customer_name'] ?? ''));
    $email = trim((string) ($_POST['customer_email'] ?? ''));
    if ($name === '' || mb_strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        $error = 'Enter your name and a valid email address.';
    } elseif (!$_SESSION['cart']) {
        $error = 'Your cart is empty.';
    } else {
        try {
            $conn->begin_transaction();
            $orderLines = [];
            $total = 0.0;
            $lookup = $conn->prepare('SELECT title, price, stock FROM products WHERE id = ? FOR UPDATE');
            foreach ($_SESSION['cart'] as $id => $quantity) {
                $id = (int) $id;
                $quantity = (int) $quantity;
                $lookup->bind_param('i', $id);
                $lookup->execute();
                $product = $lookup->get_result()->fetch_assoc();
                if (!$product || $quantity < 1 || $quantity > (int) $product['stock']) {
                    throw new RuntimeException('A cart item is unavailable or the requested quantity exceeds stock. Please review your cart.');
                }
                $unitPrice = (float) $product['price'];
                $total += $unitPrice * $quantity;
                $orderLines[] = ['id' => $id, 'title' => $product['title'], 'price' => $unitPrice, 'quantity' => $quantity];
            }
            if (!$orderLines || $total <= 0) {
                throw new RuntimeException('Your cart is empty.');
            }

            $userId = isset($_SESSION['user']['id']) ? (int) $_SESSION['user']['id'] : null;
            $orderStmt = $conn->prepare('INSERT INTO orders (user_id, customer_name, customer_email, total_amount, status) VALUES (?, ?, ?, ?, \'new\')');
            $orderStmt->bind_param('issd', $userId, $name, $email, $total);
            $orderStmt->execute();
            $orderId = (int) $conn->insert_id;

            $lineStmt = $conn->prepare('INSERT INTO order_items (order_id, product_id, product_title, unit_price, quantity) VALUES (?, ?, ?, ?, ?)');
            $stockStmt = $conn->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
            foreach ($orderLines as $line) {
                $productId = $line['id'];
                $title = $line['title'];
                $price = $line['price'];
                $quantity = $line['quantity'];
                $lineStmt->bind_param('iisdi', $orderId, $productId, $title, $price, $quantity);
                $lineStmt->execute();
                $stockStmt->bind_param('ii', $quantity, $productId);
                $stockStmt->execute();
            }
            $conn->commit();
            $_SESSION['cart'] = [];
            set_flash('success', 'Order #' . $orderId . ' has been saved. No payment was taken or processed.');
            redirect('shop.php');
        } catch (Throwable $exception) {
            $conn->rollback();
            $error = ($exception instanceof RuntimeException) ? $exception->getMessage() : 'We could not save the order. Please try again.';
        }
    }
}

$summary = [];
$total = 0.0;
foreach ($_SESSION['cart'] as $id => $quantity) {
    $id = (int) $id;
    $stmt = $conn->prepare('SELECT title, price, stock FROM products WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    if (!$product || (int) $product['stock'] < 1) {
        unset($_SESSION['cart'][$id]);
        continue;
    }
    $quantity = min(max(1, (int) $quantity), (int) $product['stock']);
    $_SESSION['cart'][$id] = $quantity;
    $product['quantity'] = $quantity;
    $product['line_total'] = (float) $product['price'] * $quantity;
    $total += $product['line_total'];
    $summary[] = $product;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?>
    <main class="container py-5 mt-5">
        <div class="pt-4">
            <h1 class="fw-bold">Checkout</h1>
            <p class="text-secondary">Confirm your order details. This checkout does not take payment.</p>
        </div><?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if (!$summary): ?><div class="bg-white rounded-4 shadow-sm p-5 text-center">
                <h2 class="h4">Nothing to check out</h2>
                <p class="text-secondary">Add items to your cart first.</p>
                <a href="shop.php" class="btn btn-primary-custom">Browse the menu</a>
            </div><?php else: ?><div class="row g-4">
                <div class="col-lg-7">
                    <div class="bg-white rounded-4 shadow-sm p-4">
                        <h2 class="h5 fw-bold mb-3">Contact details</h2>
                        <form method="post" action="checkout.php">
                            <?= csrf_field() ?><div class="mb-3">
                                <label class="form-label" for="customer-name">Name</label>
                                <input class="form-control" id="customer-name" name="customer_name" maxlength="100" value="<?= e($name) ?>" required>
                            </div>
                            <div class="mb-4"><label class="form-label" for="customer-email">Email</label>
                                <input class="form-control" id="customer-email" name="customer_email" type="email" maxlength="190" value="<?= e($email) ?>" required>
                            </div>
                            <button class="btn btn-primary-custom w-100 py-3" type="submit">Place order (no payment)</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="bg-white rounded-4 shadow-sm p-4">
                        <h2 class="h5 fw-bold mb-3">Order summary</h2>
                        <?php foreach ($summary as $line): ?>
                            <div class="d-flex justify-content-between gap-3 mb-3">
                                <span><?= e($line['title']) ?> × <?= (int) $line['quantity'] ?></span>
                                <strong><?= number_format($line['line_total'], 0) ?> MMK</strong>
                            </div>
                        <?php endforeach; ?>
                        <hr>
                        <div class="d-flex justify-content-between h5 mb-0"><span>Total</span>
                            <strong><?= number_format($total, 0) ?> MMK</strong>
                        </div>
                        <p class="small text-muted mt-3 mb-0">Payment integration is not included. Your order will be recorded as new.</p>
                        <a href="cart.php" class="d-inline-block mt-3">Back to cart</a>
                    </div>
                </div>
            </div><?php endif; ?>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>