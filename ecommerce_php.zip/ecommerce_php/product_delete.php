<?php
require_once __DIR__ . '/connection.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Delete products using the inventory form.');
}
verify_csrf();
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id) {
    set_flash('danger', 'A valid product ID is required.');
    redirect('product.php');
}
$stmt = $conn->prepare('SELECT image FROM products WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
if (!$product) {
    set_flash('warning', 'That product was not found.');
    redirect('product.php');
}
$delete = $conn->prepare('DELETE FROM products WHERE id = ?');
$delete->bind_param('i', $id);
$delete->execute();
$image = (string) $product['image'];
if (str_starts_with($image, 'uploads/products/') && preg_match('~^uploads/products/[A-Za-z0-9_.-]+$~D', $image)) {
    $imageFile = __DIR__ . '/' . $image;
    if (is_file($imageFile)) {
        unlink($imageFile);
    }
}
set_flash('success', 'Product deleted. Any saved order history has been retained.');
redirect('product.php');
?>
