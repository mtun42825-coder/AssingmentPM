<?php
require_once __DIR__ . '/connection.php';
if (!empty($_SESSION['user'])) {
    redirect('shop.php');
}
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $stmt = $conn->prepare('SELECT id, username, email, password_hash, role FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int) $user['id'], 'username' => $user['username'], 'email' => $user['email'], 'role' => $user['role']];
        set_flash('success', 'You are now signed in.');
        redirect('shop.php');
    }
    $error = 'The username or password was not recognized.';
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?><main class="container py-5 mt-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5">
                <div class="bg-white rounded-4 shadow-sm p-4 p-md-5"><a href="index.php" class="text-decoration-none text-primary">← Back to home</a>
                    <h1 class="h2 fw-bold mt-4 mb-4">Sign in</h1>
                    <?php if ($flash): ?>
                        <div class="alert alert-<?= e($flash['type']) ?>">
                            <?= e($flash['message']) ?>
                        </div>
                        <?php endif; ?>
                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger">
                                <?= e($error) ?></div>
                                <?php endif;
                                 ?>
                    <form method="post" action="login.php" autocomplete="on">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label fw-bold" for="username">Username</label>
                            <input class="form-control" id="username" name="username" maxlength="50" value="<?= e($username) ?>" required autocomplete="username">
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold" for="password">Password</label>
                            <input class="form-control" id="password" name="password" type="password" required autocomplete="current-password"></div>
                        <button class="btn btn-primary-custom w-100 py-3" type="submit">Log in</button>
                    </form>
                    <p class="small text-secondary text-center mt-4 mb-0">Need an account? <a href="register.php">Register</a></p>
                </div>
            </div>
        </div>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>