<?php
require_once __DIR__ . '/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action'] ?? '') === 'contact') {
    verify_csrf();
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $message = trim((string) ($_POST['message'] ?? ''));
    if ($name === '' || mb_strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190 || $message === '' || mb_strlen($message) > 5000) {
        set_flash('danger', 'Please provide a name, valid email address, and a message under 5,000 characters.');
    } else {
        $stmt = $conn->prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $name, $email, $message);
        $stmt->execute();
        set_flash('success', 'Thanks for your message. Our team will be in touch.');
    }
    redirect('index.php#contact');
}

$flash = get_flash();
$featured = $conn->query('SELECT id, title, description, price, image FROM products WHERE stock > 0 ORDER BY id DESC LIMIT 3');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danger-X Kitchen | Fresh favourites</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/swiper-bundle.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .product-card img {
            width: 100%;
            height: 260px;
            object-fit: cover;
            border-radius: 12px
        }

        .hero-section .swiper-slide {
            background-position: center;
            background-size: cover
        }

        .hero-section .swiper {
            height: 65vh;
            min-height: 390px
        }
    </style>
</head>

<body>
    <?php include __DIR__ . '/navbar.php'; ?>
    <section class="hero-section">
        <div class="swiper mainSwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide" style="background-image:url('images/coca_cola.jpg')">
                    <div class="hero-overlay">
                        <div class="container text-white">
                            <h1 class="display-3 fw-bold">Good food, good mood.</h1>
                            <p class="lead">Freshly made favourites, ready for your next meal.</p><a href="shop.php" class="btn btn-primary-custom btn-lg">Browse the menu</a>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide" style="background-image:url('images/spicy_chicken_sandwich.jpg')">
                    <div class="hero-overlay">
                        <div class="container text-white">
                            <h1 class="display-3 fw-bold">Made for sharing.</h1>
                            <p class="lead">Burgers, sides, drinks and more from Danger-X Kitchen.</p><a href="shop.php" class="btn btn-primary-custom btn-lg">Order something tasty</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
    <?php if ($flash): ?>
        <div class="container mt-4">
            <div class="alert alert-<?= e($flash['type']) ?> mb-0"><?= e($flash['message']) ?></div>
        </div>
        <?php endif; ?>
    <section class="py-5" id="about">
        <div class="container py-4">
            <div class="row align-items-center g-4">
                <div class="col-lg-6"><img src="images/classic_booki_burger.jpg" class="img-fluid rounded-4 shadow-sm" alt="Fresh Danger-X burger"></div>
                <div class="col-lg-6 ps-lg-5">
                    <h6 class="text-primary fw-bold text-uppercase">Our kitchen</h6>
                    <h2 class="display-5 fw-bold mb-4">Everyday favourites, made with care.</h2>
                    <p class="text-secondary">Danger-X Kitchen brings together comforting meals and familiar flavours—from burgers and pasta to crisp sides and refreshing drinks.</p>
                    <a href="shop.php" class="btn btn-outline-primary rounded-pill px-4 py-2 mt-2">Explore the menu</a>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5 bg-light">
        <div class="container py-4">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Why order from us?</h2>
                <p class="text-secondary">Simple, reliable, and made for the moments that matter.</p>
            </div>
            <div class="row g-4 text-center">
                <div class="col-md-4">
                    <div class="service-card p-4 bg-white rounded-4 shadow-sm h-100">
                        <i class="bi bi-bag-heart text-primary display-4 mb-3"></i>
                        <h4>Familiar favourites</h4>
                        <p class="text-secondary">A straightforward menu of meals and treats you know.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card p-4 bg-white rounded-4 shadow-sm h-100">
                        <i class="bi bi-box-seam text-primary display-4 mb-3"></i>
                        <h4>Easy ordering</h4>
                        <p class="text-secondary">Choose your items and place your order in a few steps.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card p-4 bg-white rounded-4 shadow-sm h-100">
                        <i class="bi bi-chat-dots text-primary display-4 mb-3"></i>
                        <h4>Here to help</h4>
                        <p class="text-secondary">Send us a message and our team will get back to you.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5" id="featured">
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-end mb-4">
                <div>
                    <h2 class="fw-bold mb-1">Popular picks</h2>
                    <p class="text-secondary mb-0">A few favourites from the current menu.</p>
                </div><a href="shop.php" class="btn btn-outline-primary">Full menu</a>
            </div>
            <div class="row g-4">
                <?php if ($featured->num_rows === 0): ?>
                    <div class="col-12">
                        <p class="text-secondary">The menu is being prepared. Please check back soon.</p>
                    </div>
                    <?php endif; ?>
                <?php while ($item = $featured->fetch_assoc()): ?>
                    <div class="col-md-6 col-xl-4">
                        <div class="card h-100 border-0 shadow-sm product-card">
                            <a href="shop.php" class="text-decoration-none">
                                <img src="<?= e(product_image_path($item['image'])) ?>" class="card-img-top p-2 rounded-4" alt="<?= e($item['title']) ?>"></a>
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?= e($item['title']) ?></h5>
                                <p class="text-secondary small"><?= e($item['description']) ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5 mb-0 text-primary"><?= number_format((float) $item['price'], 0) ?> MMK</span>
                                    <form method="post" action="cart.php"><?= csrf_field() ?>
                                        <input type="hidden" name="action" value="add">
                                        <input type="hidden" name="product_id" value="<?= (int) $item['id'] ?>">
                                        <button class="btn btn-primary-custom" type="submit">Add to cart</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div><?php endwhile; ?>
            </div>
        </div>
    </section>
    <section class="py-5 bg-dark text-white" id="contact">
        <div class="container py-4">
            <div class="row g-5">
                <div class="col-lg-5">
                    <h2 class="fw-bold mb-4">Get in touch</h2>
                    <p class="text-light">Have a question about the menu or your order? Send us a message.</p>
                    <p class="mb-1"><i class="bi bi-geo-alt me-2 text-primary"></i>Yangon, Myanmar</p>
                    <p><i class="bi bi-envelope me-2 text-primary"></i>hello@KoTun.local</p>
                </div>
                <div class="col-lg-7">
                    <form method="post" action="index.php#contact" class="row g-3"><?= csrf_field() ?>
                        <input type="hidden" name="form_action" value="contact">
                        <div class="col-md-6"><label class="form-label" for="contact-name">Your name</label>
                            <input id="contact-name" name="name" type="text" maxlength="100" class="form-control bg-transparent text-white" required>
                        </div>
                        <div class="col-md-6"><label class="form-label" for="contact-email">Your email</label>
                            <input id="contact-email" name="email" type="email" maxlength="190" class="form-control bg-transparent text-white" required>
                        </div>
                        <div class="col-12"><label class="form-label" for="contact-message">Message</label>
                            <textarea id="contact-message" name="message" maxlength="5000" class="form-control bg-transparent text-white" rows="4" required>

                        </textarea>
                        </div>
                        <div class="col-12"><button class="btn btn-primary-custom w-100 py-3" type="submit">Send message</button></div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        new Swiper('.mainSwiper', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev'
            },
            autoplay: {
                delay: 5000
            }
        });
    </script>
</body>

</html>