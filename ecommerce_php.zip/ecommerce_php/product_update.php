<?php
require_once __DIR__ . '/connection.php';
require_admin();
$id = filter_var($_GET['id'] ?? $_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id) {
    http_response_code(400);
    exit('A valid product ID is required.');
}
$stmt = $conn->prepare('SELECT id, title, description, category, price, stock, image FROM products WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
if (!$product) {
    http_response_code(404);
    exit('Product not found.');
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $title = trim((string) ($_POST['title'] ?? ''));
    $category = trim((string) ($_POST['category'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $stock = filter_var($_POST['stock'] ?? null, FILTER_VALIDATE_INT);
    try {
        if ($title === '' || mb_strlen($title) > 150 || $category === '' || mb_strlen($category) > 80 || $description === '' || $price === false || $price <= 0 || $stock === false || $stock < 0) {
            throw new RuntimeException('Enter a title, category, description, positive price, and stock of 0 or more.');
        }
        $newImage = store_product_image($_FILES['image'] ?? []);
        $image = $newImage ?? $product['image'];
        $update = $conn->prepare('UPDATE products SET title = ?, description = ?, category = ?, price = ?, stock = ?, image = ? WHERE id = ?');
        $update->bind_param('sssdisi', $title, $description, $category, $price, $stock, $image, $id);
        $update->execute();
        set_flash('success', 'Product updated.');
        redirect('product.php');
    } catch (Throwable $exception) {
        $error = $exception instanceof RuntimeException ? $exception->getMessage() : 'The product could not be updated. Please try again.';
    }
    $product = array_merge($product, ['title' => $title, 'description' => $description, 'category' => $category, 'price' => $price, 'stock' => $stock]);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit product | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?><main class="container py-5 mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm mt-4"><a href="product.php">← Back to inventory</a>
                    <h1 class="h2 fw-bold mt-3 mb-4">Edit product</h1>
                    <?php if ($error !== ''): ?>
                        <div class="alert alert-danger"><?= e($error) ?></div>
                        <?php endif; ?>
                        <form method="post" action="product_update.php?id=<?= (int) $id ?>" enctype="multipart/form-data">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $id ?>">
                        <div class="row g-3">
                            <div class="col-md-8"><label class="form-label fw-bold" for="title">Product name</label>
                            <input id="title" name="title" maxlength="150" class="form-control" value="<?= e($product['title']) ?>" required></div>
                            <div class="col-md-4"><label class="form-label fw-bold" for="category">Category</label>
                            <input id="category" name="category" maxlength="80" class="form-control" value="<?= e($product['category']) ?>" required></div>
                            <div class="col-md-6"><label class="form-label fw-bold" for="price">Price (MMK)</label>
                            <input id="price" name="price" type="number" min="0.01" step="0.01" class="form-control" value="<?= e($product['price']) ?>" required></div>
                            <div class="col-md-6"><label class="form-label fw-bold" for="stock">Stock quantity</label>
                            <input id="stock" name="stock" type="number" min="0" class="form-control" value="<?= (int) $product['stock'] ?>" required></div>
                            <div class="col-12"><label class="form-label fw-bold" for="description">Description</label>
                            <textarea id="description" name="description" class="form-control" rows="4" required><?= e($product['description']) ?></textarea></div>
                            <div class="col-12">
                                <p class="mb-2">Current image:</p><img src="<?= e(product_image_path($product['image'])) ?>" alt="" width="110" height="90" class="rounded object-fit-cover">
                                <label class="form-label fw-bold d-block mt-3" for="image">Replace image (optional)</label>
                                <input id="image" type="file" name="image" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
                                <div class="form-text">JPG, PNG, GIF, or WebP; up to 5 MB.</div>
                            </div>
                            <div class="col-12 d-flex gap-2 mt-4">
                                <button type="submit" class="btn btn-primary-custom px-4">Save changes</button>
                                <a href="product.php" class="btn btn-outline-secondary">Cancel</a></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>