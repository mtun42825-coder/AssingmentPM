<?php
// XAMPP defaults: MySQL on localhost, user root, no password, database ecommerce.
// These can be overridden with DB_HOST, DB_USER, DB_PASS, and DB_NAME environment variables.
require_once __DIR__ . '/includes/app.php';

$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPass = getenv('DB_PASS') ?: '';
$dbName = getenv('DB_NAME') ?: 'ecommerce';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $exception) {
    http_response_code(500);
    exit('Could not connect to MySQL. Start MySQL in XAMPP and import database/ecommerce.sql in phpMyAdmin.');
}
?>
