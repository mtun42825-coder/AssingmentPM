<?php
// connection.php starts the session before the shared navbar is included.
$cartCount = 0;
foreach (($_SESSION['cart'] ?? []) as $quantity) {
    $cartCount += (int) $quantity;
}
$currentUser = $_SESSION['user'] ?? null;
?>
<nav class="navbar navbar-expand-lg fixed-top custom-navbar">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">
            <span class="brand-accent">Danger-</span>X <small class="text-secondary">Kitchen</small></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="shop.php">Menu</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.php">Cart <span class="badge bg-primary"><?= $cartCount ?></span></a></li>
                <?php if (($currentUser['role'] ?? '') === 'admin'): ?>
                    <li class="nav-item"><a class="nav-link" href="product.php">Inventory</a></li>
                <?php endif; ?>
            </ul>
            <div class="dropdown">
                <a href="#" class="user-icon-link d-flex align-items-center justify-content-center" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Account menu">
                    <i class="bi bi-person-circle"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-3 custom-dropdown" aria-labelledby="userDropdown">
                    <?php if ($currentUser): ?>
                        <li>
                            <h6 class="dropdown-header">Hello, <?= e($currentUser['username']) ?></h6>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form method="post" action="logout.php" class="px-3 py-1"><?= csrf_field() ?>
                            <button class="btn btn-link dropdown-item p-0" type="submit">
                                <i class="bi bi-box-arrow-right me-2"></i>Sign out</button></form>
                        </li>
                    <?php else: ?>
                        <li>
                            <h6 class="dropdown-header">Welcome!</h6>
                        </li>
                        <li><a class="dropdown-item" href="login.php"><i class="bi bi-box-arrow-in-right me-2"></i>Login</a></li>
                        <li><a class="dropdown-item" href="register.php"><i class="bi bi-pencil-square me-2"></i>Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>