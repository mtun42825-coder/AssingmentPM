<?php
require_once __DIR__ . '/connection.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $title = trim((string) ($_POST['title'] ?? ''));
    $category = trim((string) ($_POST['category'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $stock = filter_var($_POST['stock'] ?? null, FILTER_VALIDATE_INT);
    try {
        if ($title === '' || mb_strlen($title) > 150 || $category === '' || mb_strlen($category) > 80 || $description === '' || $price === false || $price <= 0 || $stock === false || $stock < 0) {
            throw new RuntimeException('Enter a title, category, description, positive price, and stock of 0 or more.');
        }
        $image = store_product_image($_FILES['image'] ?? []);
        $image = $image ?? 'images/classic_booki_burger.jpg';
        $stmt = $conn->prepare('INSERT INTO products (title, description, category, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssdis', $title, $description, $category, $price, $stock, $image);
        $stmt->execute();
        set_flash('success', 'Product added to the menu.');
    } catch (Throwable $exception) {
        set_flash('danger', $exception instanceof RuntimeException ? $exception->getMessage() : 'The product could not be saved.');
    }
    redirect('product.php');
}

$flash = get_flash();
$countRow = $conn->query('SELECT COUNT(*) AS total FROM products')->fetch_assoc();
$products = $conn->query('SELECT id, title, category, price, stock, image FROM products ORDER BY id DESC');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inventory | Danger-X Kitchen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light"><?php include __DIR__ . '/navbar.php'; ?><main class="container py-5 mt-5">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 pt-4">
            <div>
                <h1 class="fw-bold mb-1">Product inventory</h1>
                <p class="text-secondary mb-0">Manage the menu, descriptions, prices, and stock.</p>
            </div><button class="btn btn-primary-custom px-4 py-2" data-bs-toggle="modal" data-bs-target="#addProductModal"><i class="bi bi-plus-lg me-2"></i>Add product</button>
        </div><?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?><div class="bg-white rounded-4 p-3 shadow-sm mb-4"><small class="text-secondary text-uppercase fw-bold">Total products</small>
            <h2 class="h3 fw-bold mb-0"><?= (int) $countRow['total'] ?></h2>
        </div>
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3">Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($products->num_rows === 0): ?><tr>
                                <td colspan="5" class="text-center text-secondary py-5">No products yet. Add the first menu item.</td>
                            </tr><?php endif; ?><?php while ($product = $products->fetch_assoc()): ?><tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <img src="<?= e(product_image_path($product['image'])) ?>" class="rounded-3 me-3" width="52" height="52" style="object-fit:cover" alt=""><strong>
                                            <?= e($product['title']) ?></strong>
                                    </div>
                                </td>
                                <td><?= e($product['category']) ?></td>
                                <td class="fw-bold text-primary"><?= number_format((float) $product['price'], 0) ?> MMK</td>
                                <td><?= (int) $product['stock'] ?></td>
                                <td class="text-end pe-4">
                                    <a href="product_update.php?id=<?= (int) $product['id'] ?>" class="btn btn-light btn-sm" aria-label="Edit <?= e($product['title']) ?>">
                                        <i class="bi bi-pencil text-primary"></i></a>
                                    <form method="post" action="product_delete.php" class="d-inline" onsubmit="return confirm('Delete this product? Its saved order history will be retained.');"><?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $product['id'] ?>">
                                        <button class="btn btn-light btn-sm" type="submit" aria-label="Delete <?= e($product['title']) ?>"><i class="bi bi-trash text-danger"></i></button>
                                    </form>
                                </td>
                            </tr><?php endwhile; ?></tbody>
                </table>
            </div>
        </div>
    </main>
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header border-0 px-4 pt-4">
                    <h2 class="h5 fw-bold" id="addProductTitle">Add menu item</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-4 pb-4">
                    <form method="post" action="product.php" enctype="multipart/form-data"><?= csrf_field() ?><div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label small fw-bold" for="new-title">Product name</label>
                                <input id="new-title" name="title" type="text" maxlength="150" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold" for="new-category">Category</label>
                                <input id="new-category" name="category" type="text" maxlength="80" class="form-control" placeholder="Burgers" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold" for="new-price">Price (MMK)</label>
                                <input id="new-price" name="price" type="number" min="0.01" step="0.01" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold" for="new-stock">Stock quantity</label>
                                <input id="new-stock" name="stock" type="number" min="0" step="1" value="0" class="form-control" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold" for="new-description">Description</label>
                                <textarea id="new-description" name="description" class="form-control" rows="3" required></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold" for="new-image">Product image (optional; JPG, PNG, GIF, or WebP, up to 5 MB)</label>
                                <input id="new-image" type="file" name="image" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
                            </div>
                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary-custom w-100 py-3">Save product</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>