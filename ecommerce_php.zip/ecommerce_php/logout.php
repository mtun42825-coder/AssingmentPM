<?php
require_once __DIR__ . '/connection.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Use the sign-out button in the account menu.');
}
verify_csrf();
unset($_SESSION['user']);
session_regenerate_id(true);
set_flash('success', 'You have been signed out.');
redirect('index.php');
?>
